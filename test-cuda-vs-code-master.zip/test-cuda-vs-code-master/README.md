## test-cuda-vs-code

This is to test cuda c/c++ code in vs-code in windows.

### Please refer to my blog for details about the implementation.

[How to enable CUDA C/C++ support in vs-code in Windows 10?](https://ericzhng.github.io/posts/2018/blog-set-up-vc-vscode-cuda/)
