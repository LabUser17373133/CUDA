#ifndef STLNORM_H
#define STLNORM_H

//法线向量坐标
class stlNorm
{
public:
    stlNorm();
    void setXYZ(float _x, float _y, float _z);
    float x, y, z;      //坐标
private:

};

#endif // STLNORM_H
