#ifndef STLVERT_H
#define STLVERT_H

//单点坐标
class stlVert
{
public:
    stlVert();
    void setXYZ(float _x, float _y, float _z);
    float x, y, z;      //坐标
private:

};

#endif // STLVERT_H
